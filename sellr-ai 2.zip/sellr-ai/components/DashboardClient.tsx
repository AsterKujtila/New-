'use client'

import { useState, useRef, useEffect, useCallback } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'
import Image from 'next/image'
import { cn } from '@/lib/utils'

interface UserProp {
  id: string
  email: string
  full_name: string
  avatar_url: string
  monthly_messages_used: number
  monthly_messages_limit: number
  plan: 'free' | 'pro'
}

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
}

interface Session {
  id: string
  title: string
  updated_at: string
}

const STARTERS = [
  { icon: '✍️', text: 'Write a high-converting product description for my Whop offer' },
  { icon: '💰', text: 'Help me price my digital product for maximum conversions' },
  { icon: '📣', text: 'Create a TikTok hook script to promote my Whop community' },
  { icon: '🚀', text: 'Build me a 7-day launch strategy for my new digital product' },
  { icon: '📧', text: 'Write a 3-email welcome sequence for new Whop members' },
  { icon: '🔥', text: 'How do I increase my Whop conversion rate from 2% to 5%?' },
]

export default function DashboardClient({ user }: { user: UserProp }) {
  const router = useRouter()
  const supabase = createClient()

  const [sessions, setSessions] = useState<Session[]>([])
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')
  const [isStreaming, setIsStreaming] = useState(false)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [usage, setUsage] = useState({
    used: user.monthly_messages_used,
    limit: user.monthly_messages_limit,
  })
  const [error, setError] = useState<string | null>(null)

  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)
  const abortRef = useRef<AbortController | null>(null)

  // Load sessions
  useEffect(() => {
    fetch('/api/sessions')
      .then((r) => r.json())
      .then(({ sessions }) => { if (sessions) setSessions(sessions) })
      .catch(() => {})
  }, [])

  // Scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  // Auto-resize textarea
  useEffect(() => {
    const ta = inputRef.current
    if (!ta) return
    ta.style.height = 'auto'
    ta.style.height = Math.min(ta.scrollHeight, 180) + 'px'
  }, [input])

  async function createSession(firstMessage: string) {
    const title =
      firstMessage.length > 40
        ? firstMessage.slice(0, 40) + '…'
        : firstMessage
    const res = await fetch('/api/sessions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title }),
    })
    const { session } = await res.json()
    setSessions((prev) => [session, ...prev])
    return session.id as string
  }

  async function loadSession(sessionId: string) {
    setActiveSessionId(sessionId)
    setSidebarOpen(false)
    setMessages([])
    const res = await fetch(`/api/messages?sessionId=${sessionId}`)
    const { messages: msgs } = await res.json()
    if (msgs) setMessages(msgs)
  }

  async function deleteSession(id: string, e: React.MouseEvent) {
    e.stopPropagation()
    await fetch(`/api/sessions?id=${id}`, { method: 'DELETE' })
    setSessions((prev) => prev.filter((s) => s.id !== id))
    if (activeSessionId === id) {
      setActiveSessionId(null)
      setMessages([])
    }
  }

  const sendMessage = useCallback(
    async (content: string) => {
      if (!content.trim() || isStreaming) return
      setError(null)

      const userMsg: Message = {
        id: crypto.randomUUID(),
        role: 'user',
        content: content.trim(),
      }
      setMessages((prev) => [...prev, userMsg])
      setInput('')
      setIsStreaming(true)

      let sessionId = activeSessionId
      if (!sessionId) {
        sessionId = await createSession(content.trim())
        setActiveSessionId(sessionId)
      }

      // Build history for API
      const history = [...messages, userMsg].map((m) => ({
        role: m.role,
        content: m.content,
      }))

      const assistantId = crypto.randomUUID()
      setMessages((prev) => [
        ...prev,
        { id: assistantId, role: 'assistant', content: '' },
      ])

      abortRef.current = new AbortController()

      try {
        const res = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ messages: history, sessionId }),
          signal: abortRef.current.signal,
        })

        if (!res.ok) {
          const { error: apiErr } = await res.json()
          throw new Error(apiErr || 'Request failed')
        }

        const reader = res.body!.getReader()
        const decoder = new TextDecoder()

        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          const chunk = decoder.decode(value)
          const lines = chunk.split('\n').filter((l) => l.startsWith('data: '))
          for (const line of lines) {
            const raw = line.slice(6)
            if (raw === '[DONE]') break
            try {
              const { text, error: streamErr } = JSON.parse(raw)
              if (streamErr) throw new Error(streamErr)
              if (text) {
                setMessages((prev) =>
                  prev.map((m) =>
                    m.id === assistantId
                      ? { ...m, content: m.content + text }
                      : m
                  )
                )
              }
            } catch {}
          }
        }

        setUsage((prev) => ({ ...prev, used: prev.used + 1 }))
      } catch (err: unknown) {
        if (err instanceof Error && err.name === 'AbortError') return
        const msg = err instanceof Error ? err.message : 'Something went wrong'
        setError(msg)
        setMessages((prev) => prev.filter((m) => m.id !== assistantId))
      } finally {
        setIsStreaming(false)
      }
    },
    [activeSessionId, isStreaming, messages]
  )

  async function handleSignOut() {
    await supabase.auth.signOut()
    router.push('/login')
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage(input)
    }
  }

  const usagePct = Math.min((usage.used / usage.limit) * 100, 100)

  return (
    <div
      className="flex h-screen overflow-hidden"
      style={{ background: 'var(--bg-primary)' }}
    >
      {/* ─── Sidebar ─────────────────────────────────────────────────────── */}
      <>
        {/* Mobile overlay */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 z-20 bg-black/60 backdrop-blur-sm lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        <aside
          className={cn(
            'fixed inset-y-0 left-0 z-30 flex w-72 flex-col transition-transform duration-300 lg:static lg:translate-x-0',
            sidebarOpen ? 'translate-x-0' : '-translate-x-full'
          )}
          style={{
            background: 'var(--bg-secondary)',
            borderRight: '1px solid var(--border)',
          }}
        >
          {/* Logo */}
          <div
            className="flex items-center justify-between px-5 py-4"
            style={{ borderBottom: '1px solid var(--border)' }}
          >
            <div className="text-xl font-black tracking-tight">
              <span className="text-gradient">SELLR</span>
              <span style={{ color: 'var(--text-primary)' }}>.ai</span>
            </div>
            <button
              onClick={() => setSidebarOpen(false)}
              className="lg:hidden p-1 rounded"
              style={{ color: 'var(--text-muted)' }}
            >
              ✕
            </button>
          </div>

          {/* New Chat */}
          <div className="px-3 pt-3 pb-2">
            <button
              onClick={() => {
                setActiveSessionId(null)
                setMessages([])
                setSidebarOpen(false)
              }}
              className="btn-primary w-full text-sm py-2"
            >
              + New Chat
            </button>
          </div>

          {/* Sessions */}
          <div className="flex-1 overflow-y-auto px-3 py-2 space-y-1">
            {sessions.length === 0 && (
              <p
                className="text-xs text-center py-6"
                style={{ color: 'var(--text-muted)' }}
              >
                No chats yet. Start a conversation!
              </p>
            )}
            {sessions.map((s) => (
              <div
                key={s.id}
                onClick={() => loadSession(s.id)}
                className={cn(
                  'group flex items-center justify-between px-3 py-2 rounded-lg cursor-pointer text-sm transition-colors',
                  activeSessionId === s.id
                    ? 'bg-white/10'
                    : 'hover:bg-white/5'
                )}
              >
                <span
                  className="truncate flex-1"
                  style={{
                    color:
                      activeSessionId === s.id
                        ? 'var(--text-primary)'
                        : 'var(--text-muted)',
                  }}
                >
                  💬 {s.title}
                </span>
                <button
                  onClick={(e) => deleteSession(s.id, e)}
                  className="ml-2 opacity-0 group-hover:opacity-100 transition-opacity text-xs px-1 rounded hover:bg-white/10"
                  style={{ color: 'var(--danger)' }}
                  title="Delete"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>

          {/* User + usage */}
          <div
            className="px-4 py-4 space-y-3"
            style={{ borderTop: '1px solid var(--border)' }}
          >
            {/* Usage bar */}
            <div>
              <div
                className="flex justify-between text-xs mb-1"
                style={{ color: 'var(--text-muted)' }}
              >
                <span>Messages</span>
                <span>
                  {usage.used}/{usage.limit}
                </span>
              </div>
              <div
                className="h-1.5 rounded-full overflow-hidden"
                style={{ background: 'rgba(255,255,255,0.08)' }}
              >
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${usagePct}%`,
                    background:
                      usagePct > 90
                        ? 'var(--danger)'
                        : 'var(--accent)',
                  }}
                />
              </div>
              {user.plan === 'free' && (
                <p
                  className="text-xs mt-1"
                  style={{ color: 'var(--text-muted)' }}
                >
                  Free plan · 50 msgs/month
                </p>
              )}
            </div>

            {/* User row */}
            <div className="flex items-center gap-2">
              {user.avatar_url ? (
                <Image
                  src={user.avatar_url}
                  alt={user.full_name}
                  width={32}
                  height={32}
                  className="rounded-full"
                />
              ) : (
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold"
                  style={{ background: 'var(--accent)', color: '#fff' }}
                >
                  {(user.full_name || user.email)[0].toUpperCase()}
                </div>
              )}
              <div className="flex-1 min-w-0">
                <p
                  className="text-xs font-medium truncate"
                  style={{ color: 'var(--text-primary)' }}
                >
                  {user.full_name || user.email}
                </p>
                <p className="text-xs capitalize" style={{ color: 'var(--text-muted)' }}>
                  {user.plan} plan
                </p>
              </div>
              <button
                onClick={handleSignOut}
                className="btn-ghost text-xs px-2 py-1"
                title="Sign out"
              >
                ↪
              </button>
            </div>
          </div>
        </aside>
      </>

      {/* ─── Main ─────────────────────────────────────────────────────────── */}
      <div className="flex flex-1 flex-col min-w-0">
        {/* Top bar */}
        <header
          className="flex items-center gap-3 px-4 py-3 shrink-0"
          style={{ borderBottom: '1px solid var(--border)' }}
        >
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden p-2 rounded-lg"
            style={{ color: 'var(--text-muted)', background: 'var(--bg-card)' }}
          >
            ☰
          </button>
          <div className="flex-1">
            <p className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>
              {activeSessionId
                ? sessions.find((s) => s.id === activeSessionId)?.title || 'Chat'
                : 'New Chat'}
            </p>
          </div>
          <div
            className="hidden sm:flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full"
            style={{
              background: 'rgba(14,165,233,0.1)',
              color: 'var(--accent)',
              border: '1px solid rgba(14,165,233,0.2)',
            }}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse" />
            Claude AI
          </div>
        </header>

        {/* Messages area */}
        <div className="flex-1 overflow-y-auto px-4 py-6">
          {messages.length === 0 ? (
            <EmptyState onStart={sendMessage} />
          ) : (
            <div className="max-w-3xl mx-auto space-y-6 pb-4">
              {messages.map((msg) => (
                <MessageBubble key={msg.id} message={msg} />
              ))}
              {isStreaming &&
                messages[messages.length - 1]?.role === 'assistant' &&
                messages[messages.length - 1]?.content === '' && (
                  <TypingIndicator />
                )}
              {error && (
                <div
                  className="text-sm p-3 rounded-lg"
                  style={{
                    background: 'rgba(239,68,68,0.1)',
                    border: '1px solid rgba(239,68,68,0.2)',
                    color: '#f87171',
                  }}
                >
                  ⚠️ {error}
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input bar */}
        <div
          className="px-4 py-4 shrink-0"
          style={{ borderTop: '1px solid var(--border)' }}
        >
          <div className="max-w-3xl mx-auto">
            <div
              className="flex items-end gap-2 p-2 rounded-2xl"
              style={{
                background: 'rgba(255,255,255,0.05)',
                border: '1px solid var(--border)',
              }}
            >
              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask your sales coach…"
                disabled={isStreaming}
                rows={1}
                className="flex-1 resize-none bg-transparent outline-none text-sm leading-relaxed py-2 px-2"
                style={{
                  color: 'var(--text-primary)',
                  maxHeight: '180px',
                }}
              />
              <button
                onClick={() => sendMessage(input)}
                disabled={!input.trim() || isStreaming}
                className="shrink-0 w-9 h-9 rounded-xl flex items-center justify-center transition-all"
                style={{
                  background:
                    input.trim() && !isStreaming
                      ? 'var(--accent)'
                      : 'rgba(255,255,255,0.08)',
                  color:
                    input.trim() && !isStreaming
                      ? '#fff'
                      : 'var(--text-muted)',
                }}
              >
                {isStreaming ? (
                  <span className="w-3 h-3 border-2 border-current border-t-transparent rounded-full animate-spin" />
                ) : (
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" />
                  </svg>
                )}
              </button>
            </div>
            <p
              className="text-xs text-center mt-2"
              style={{ color: 'var(--text-muted)' }}
            >
              Press Enter to send · Shift+Enter for new line
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

// ─── Sub-components ────────────────────────────────────────────────────────────

function EmptyState({ onStart }: { onStart: (t: string) => void }) {
  return (
    <div className="flex flex-col items-center justify-center min-h-full py-12 px-4">
      <div className="mb-2 text-4xl font-black tracking-tight text-center">
        <span className="text-gradient">SELLR</span>
        <span style={{ color: 'var(--text-primary)' }}>.ai</span>
      </div>
      <p
        className="text-sm mb-10 text-center"
        style={{ color: 'var(--text-muted)' }}
      >
        Your personal AI sales coach for Whop
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-2xl">
        {STARTERS.map((s) => (
          <button
            key={s.text}
            onClick={() => onStart(s.text)}
            className="text-left p-4 rounded-xl transition-all text-sm"
            style={{
              background: 'var(--bg-card)',
              border: '1px solid var(--border)',
              color: 'var(--text-muted)',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = 'var(--bg-card-hover)'
              e.currentTarget.style.borderColor = 'rgba(14,165,233,0.3)'
              e.currentTarget.style.color = 'var(--text-primary)'
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'var(--bg-card)'
              e.currentTarget.style.borderColor = 'var(--border)'
              e.currentTarget.style.color = 'var(--text-muted)'
            }}
          >
            <span className="mr-2">{s.icon}</span>
            {s.text}
          </button>
        ))}
      </div>
    </div>
  )
}

function MessageBubble({ message }: { message: Message }) {
  const isUser = message.role === 'user'

  return (
    <div
      className={cn(
        'msg-in flex gap-3',
        isUser ? 'justify-end' : 'justify-start'
      )}
    >
      {!isUser && (
        <div
          className="shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold"
          style={{ background: 'linear-gradient(135deg, var(--accent), var(--accent-2))', color: '#fff' }}
        >
          S
        </div>
      )}
      <div
        className={cn(
          'max-w-[80%] sm:max-w-[70%] rounded-2xl px-4 py-3 text-sm leading-relaxed',
          isUser
            ? 'rounded-br-sm'
            : 'rounded-bl-sm'
        )}
        style={{
          background: isUser
            ? 'var(--accent)'
            : 'rgba(255,255,255,0.06)',
          color: isUser ? '#fff' : 'var(--text-primary)',
          border: isUser ? 'none' : '1px solid var(--border)',
        }}
      >
        {isUser ? (
          <p style={{ whiteSpace: 'pre-wrap' }}>{message.content}</p>
        ) : (
          <div
            className="prose-sellr"
            dangerouslySetInnerHTML={{ __html: parseMarkdown(message.content) }}
          />
        )}
      </div>
      {isUser && (
        <div
          className="shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold"
          style={{ background: 'rgba(255,255,255,0.12)', color: 'var(--text-primary)' }}
        >
          U
        </div>
      )}
    </div>
  )
}

function TypingIndicator() {
  return (
    <div className="flex gap-3 items-start">
      <div
        className="shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold"
        style={{ background: 'linear-gradient(135deg, var(--accent), var(--accent-2))', color: '#fff' }}
      >
        S
      </div>
      <div
        className="px-4 py-3 rounded-2xl rounded-bl-sm"
        style={{
          background: 'rgba(255,255,255,0.06)',
          border: '1px solid var(--border)',
        }}
      >
        <div className="flex gap-1 items-center h-5">
          <span className="dot-1 w-2 h-2 rounded-full inline-block" style={{ background: 'var(--text-muted)' }} />
          <span className="dot-2 w-2 h-2 rounded-full inline-block" style={{ background: 'var(--text-muted)' }} />
          <span className="dot-3 w-2 h-2 rounded-full inline-block" style={{ background: 'var(--text-muted)' }} />
        </div>
      </div>
    </div>
  )
}

// Minimal safe markdown → HTML (no external lib needed)
function parseMarkdown(text: string): string {
  if (!text) return ''
  let html = text
    // Escape HTML
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    // Bold
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    // Italic
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    // Inline code
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    // Headers
    .replace(/^### (.*$)/gm, '<h3>$1</h3>')
    .replace(/^## (.*$)/gm, '<h2>$1</h2>')
    .replace(/^# (.*$)/gm, '<h1>$1</h1>')
    // Unordered lists
    .replace(/^\s*[-*] (.+)/gm, '<li>$1</li>')
    // Ordered lists
    .replace(/^\s*\d+\. (.+)/gm, '<li>$1</li>')
    // Blockquote
    .replace(/^> (.+)/gm, '<blockquote>$1</blockquote>')
    // Line breaks → paragraphs
    .split(/\n\n+/)
    .map((para) => {
      para = para.trim()
      if (!para) return ''
      if (para.startsWith('<h') || para.startsWith('<blockquote') || para.startsWith('<pre')) return para
      if (para.includes('<li>')) return `<ul>${para}</ul>`
      return `<p>${para.replace(/\n/g, '<br/>')}</p>`
    })
    .join('')
  return html
}
