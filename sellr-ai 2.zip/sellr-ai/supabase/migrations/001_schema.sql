-- SELLR.ai Database Schema
-- Run this in Supabase SQL Editor

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ─── Profiles ───────────────────────────────────────────────────────────────
create table if not exists public.profiles (
  id                      uuid references auth.users on delete cascade primary key,
  email                   text not null,
  full_name               text,
  avatar_url              text,
  whop_store_url          text,
  plan                    text not null default 'free' check (plan in ('free', 'pro')),
  monthly_messages_used   integer not null default 0,
  monthly_messages_limit  integer not null default 50,
  messages_reset_at       timestamptz not null default (date_trunc('month', now()) + interval '1 month'),
  created_at              timestamptz not null default now()
);

alter table public.profiles enable row level security;

create policy "Users can view own profile"
  on public.profiles for select
  using (auth.uid() = id);

create policy "Users can update own profile"
  on public.profiles for update
  using (auth.uid() = id);

-- ─── Chat Sessions ──────────────────────────────────────────────────────────
create table if not exists public.chat_sessions (
  id            uuid default uuid_generate_v4() primary key,
  user_id       uuid references public.profiles(id) on delete cascade not null,
  title         text not null default 'New Chat',
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

alter table public.chat_sessions enable row level security;

create policy "Users can manage own sessions"
  on public.chat_sessions for all
  using (auth.uid() = user_id);

-- ─── Messages ────────────────────────────────────────────────────────────────
create table if not exists public.messages (
  id            uuid default uuid_generate_v4() primary key,
  session_id    uuid references public.chat_sessions(id) on delete cascade not null,
  user_id       uuid references public.profiles(id) on delete cascade not null,
  role          text not null check (role in ('user', 'assistant')),
  content       text not null,
  created_at    timestamptz not null default now()
);

alter table public.messages enable row level security;

create policy "Users can manage own messages"
  on public.messages for all
  using (auth.uid() = user_id);

-- ─── Auto-create profile on sign-up ─────────────────────────────────────────
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, full_name, avatar_url)
  values (
    new.id,
    new.email,
    new.raw_user_meta_data->>'full_name',
    new.raw_user_meta_data->>'avatar_url'
  );
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ─── Increment message count (called after each AI reply) ────────────────────
create or replace function public.increment_message_count(user_id uuid)
returns void as $$
begin
  update public.profiles
  set monthly_messages_used = monthly_messages_used + 1
  where id = user_id;
end;
$$ language plpgsql security definer;

-- ─── Monthly reset function ──────────────────────────────────────────────────
create or replace function public.reset_monthly_messages()
returns void as $$
begin
  update public.profiles
  set
    monthly_messages_used = 0,
    messages_reset_at = date_trunc('month', now()) + interval '1 month'
  where messages_reset_at <= now();
end;
$$ language plpgsql security definer;
