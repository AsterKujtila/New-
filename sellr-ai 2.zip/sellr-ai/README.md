# SELLR.ai — AI Sales Coach for Whop Sellers

> Built with Next.js 14 · Supabase · Anthropic Claude · Tailwind CSS

---

## Stack

| Layer | Tech |
|-------|------|
| Framework | Next.js 14 (App Router) |
| Auth | Supabase (Google OAuth via PKCE) |
| Database | Supabase (PostgreSQL + RLS) |
| AI | Anthropic Claude (streaming) |
| Styling | Tailwind CSS + custom glassmorphism |
| Hosting | Vercel |

---

## Deploy in 5 Steps

### 1. Clone & push to GitHub

```bash
git init
git add .
git commit -m "Initial commit — SELLR.ai"
git remote add origin https://github.com/YOUR_USERNAME/sellr-ai.git
git push -u origin main
```

### 2. Supabase setup

1. Create a project at [supabase.com](https://supabase.com)
2. Go to **SQL Editor** → paste and run `supabase/migrations/001_schema.sql`
3. Go to **Authentication → Providers → Google → Enable**
4. Add your Google OAuth **Client ID** and **Client Secret**
   - Get these from [console.cloud.google.com](https://console.cloud.google.com) → Credentials → OAuth 2.0 Client
5. Go to **Authentication → URL Configuration → Redirect URLs** and add:
   ```
   https://YOUR_APP.vercel.app/auth/callback
   http://localhost:3000/auth/callback
   ```

### 3. Get your environment variables

From Supabase → **Settings → API**:
- `NEXT_PUBLIC_SUPABASE_URL` — Project URL
- `NEXT_PUBLIC_SUPABASE_ANON_KEY` — anon/public key

From Anthropic Console:
- `ANTHROPIC_API_KEY` — your `sk-ant-api03-...` key

### 4. Deploy to Vercel

1. Go to [vercel.com/new](https://vercel.com/new) → Import your GitHub repo
2. Add these environment variables:

```
NEXT_PUBLIC_SUPABASE_URL       = https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY  = eyJ...
ANTHROPIC_API_KEY              = sk-ant-api03-...
NEXT_PUBLIC_APP_URL            = https://YOUR_APP.vercel.app
```

3. Click **Deploy**

### 5. Update Google OAuth redirect

In Google Cloud Console → your OAuth Client → **Authorized redirect URIs**, add:
```
https://YOUR_SUPABASE_PROJECT.supabase.co/auth/v1/callback
```

---

## Local Development

```bash
npm install
cp .env.example .env.local
# Fill in the env vars
npm run dev
# → http://localhost:3000
```

---

## Project Structure

```
sellr-ai/
├── app/
│   ├── layout.tsx              # Root layout
│   ├── globals.css             # Design system + Tailwind
│   ├── page.tsx                # Landing page
│   ├── login/
│   │   └── page.tsx            # Google OAuth login
│   ├── dashboard/
│   │   └── page.tsx            # Dashboard (server component)
│   └── api/
│       ├── chat/route.ts       # Claude streaming proxy
│       ├── sessions/route.ts   # CRUD for chat sessions
│       ├── messages/route.ts   # Fetch messages
│       └── usage/route.ts      # Usage stats
├── components/
│   └── DashboardClient.tsx     # Full chat UI (client component)
├── lib/
│   ├── supabase/
│   │   ├── client.ts           # Browser Supabase client
│   │   └── server.ts           # Server Supabase client
│   ├── types.ts                # Shared TypeScript types
│   └── utils.ts                # Helpers (cn, formatDate, etc.)
├── middleware.ts                # Supabase session + route protection
├── supabase/
│   └── migrations/
│       └── 001_schema.sql      # Full DB schema + RLS + triggers
├── .env.example
├── next.config.js
├── tailwind.config.ts
└── tsconfig.json
```

---

## Features

- ✅ Google OAuth (one-click sign in)
- ✅ Persistent chat sessions with history
- ✅ Streaming AI responses (real-time typing)
- ✅ Monthly message quota (50 free, upgradeable)
- ✅ Mobile-first responsive UI
- ✅ Glassmorphism dark theme
- ✅ Conversation starter prompts
- ✅ Auto-session titles
- ✅ Delete chat sessions
- ✅ Row Level Security on all DB tables

---

Built by PROSPR · [whop.com](https://whop.com)
