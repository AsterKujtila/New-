import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'

export default async function Home() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (user) redirect('/dashboard')

  return (
    <main
      className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden"
      style={{ background: 'var(--bg-primary)' }}
    >
      {/* Background blobs */}
      <div
        className="pointer-events-none absolute top-[-20%] left-[-10%] w-[600px] h-[600px] rounded-full opacity-20"
        style={{
          background:
            'radial-gradient(circle, rgba(14,165,233,0.4) 0%, transparent 70%)',
          filter: 'blur(80px)',
        }}
      />
      <div
        className="pointer-events-none absolute bottom-[-20%] right-[-10%] w-[500px] h-[500px] rounded-full opacity-15"
        style={{
          background:
            'radial-gradient(circle, rgba(99,102,241,0.5) 0%, transparent 70%)',
          filter: 'blur(80px)',
        }}
      />

      {/* Grid pattern */}
      <div
        className="pointer-events-none absolute inset-0 opacity-30"
        style={{
          backgroundImage: `
            linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)
          `,
          backgroundSize: '60px 60px',
        }}
      />

      <div className="relative z-10 flex flex-col items-center px-6 text-center max-w-3xl mx-auto">
        {/* Badge */}
        <div
          className="glass-sm mb-8 px-4 py-1.5 text-xs font-semibold tracking-widest uppercase"
          style={{ color: 'var(--accent)' }}
        >
          Powered by Claude AI
        </div>

        {/* Logo */}
        <div className="mb-6 text-6xl sm:text-7xl font-black tracking-tight leading-none">
          <span className="text-gradient">SELLR</span>
          <span style={{ color: 'var(--text-primary)' }}>.ai</span>
        </div>

        {/* Tagline */}
        <p
          className="text-xl sm:text-2xl font-light mb-3 leading-relaxed"
          style={{ color: 'var(--text-primary)' }}
        >
          Your AI Sales Coach for{' '}
          <span className="font-semibold" style={{ color: 'var(--accent)' }}>
            Whop Sellers
          </span>
        </p>
        <p
          className="text-base mb-12 max-w-lg"
          style={{ color: 'var(--text-muted)' }}
        >
          Get instant advice on pricing, copy, conversions, and scaling your
          digital product business — trained for the Whop ecosystem.
        </p>

        {/* CTA */}
        <Link href="/login" className="btn-primary text-base px-8 py-3 glow-accent">
          Start for Free →
        </Link>

        {/* Features */}
        <div className="mt-16 grid grid-cols-1 sm:grid-cols-3 gap-4 w-full">
          {[
            {
              icon: '💬',
              title: 'Sales Copy',
              desc: 'High-converting product descriptions and headlines',
            },
            {
              icon: '📈',
              title: 'Growth Strategy',
              desc: 'Pricing, upsells, and audience-building tactics',
            },
            {
              icon: '⚡',
              title: 'Instant Answers',
              desc: 'No fluff. Direct, actionable advice every time',
            },
          ].map((f) => (
            <div key={f.title} className="glass p-5 text-left">
              <div className="text-2xl mb-2">{f.icon}</div>
              <div
                className="font-semibold mb-1 text-sm"
                style={{ color: 'var(--text-primary)' }}
              >
                {f.title}
              </div>
              <div className="text-xs" style={{ color: 'var(--text-muted)' }}>
                {f.desc}
              </div>
            </div>
          ))}
        </div>
      </div>
    </main>
  )
}
