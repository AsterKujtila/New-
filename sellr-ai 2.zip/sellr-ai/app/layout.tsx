import type { Metadata, Viewport } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'SELLR.ai — AI Sales Coach for Whop Sellers',
  description:
    'Your personal AI sales coach. Get instant advice on pricing, copy, conversions, and growing your Whop business.',
  keywords: ['whop', 'ai sales coach', 'digital products', 'sellr'],
  openGraph: {
    title: 'SELLR.ai — AI Sales Coach for Whop Sellers',
    description: 'Get AI-powered sales coaching for your Whop business.',
    type: 'website',
  },
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#0a0a0f',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="antialiased">{children}</body>
    </html>
  )
}
