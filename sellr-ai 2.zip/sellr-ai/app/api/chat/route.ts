import { NextRequest, NextResponse } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'
import { createServerClient } from '@supabase/ssr'
import { cookies } from 'next/headers'

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY!,
})

const SYSTEM_PROMPT = `You are SELLR, an elite AI sales coach exclusively built for Whop sellers and digital product creators.

Your expertise covers:
- Writing high-converting sales copy, product descriptions, and headlines
- Pricing strategy for digital products, communities, and SaaS on Whop
- Conversion optimization (landing pages, checkout flows, trust signals)
- Audience growth: organic content, TikTok, Twitter/X, Instagram strategies
- Upsells, downsells, and maximizing customer lifetime value
- Community building and retention for Whop communities
- Launch strategies and pre-sell campaigns
- Affiliate program setup and management on Whop
- Email sequences and follow-up strategies
- Competitive positioning and differentiation

Communication style:
- Direct, confident, and actionable — no fluff
- Use bullet points and structure for clarity
- Give specific examples tailored to digital products
- Ask clarifying questions if needed to give better advice
- Be encouraging but honest — tell sellers what actually works

Always ground advice in what works specifically for the Whop platform and digital product ecosystem.`

export async function POST(request: NextRequest) {
  try {
    const cookieStore = cookies()
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() { return cookieStore.getAll() },
          setAll(cookiesToSet) {
            try {
              cookiesToSet.forEach(({ name, value, options }) =>
                cookieStore.set(name, value, options)
              )
            } catch {}
          },
        },
      }
    )

    const { data: { user }, error: authError } = await supabase.auth.getUser()
    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Check usage limit
    const { data: profile } = await supabase
      .from('profiles')
      .select('monthly_messages_used, monthly_messages_limit, messages_reset_at')
      .eq('id', user.id)
      .single()

    if (profile) {
      // Reset if needed
      if (new Date(profile.messages_reset_at) <= new Date()) {
        await supabase
          .from('profiles')
          .update({
            monthly_messages_used: 0,
            messages_reset_at: new Date(
              new Date().getFullYear(),
              new Date().getMonth() + 1,
              1
            ).toISOString(),
          })
          .eq('id', user.id)
      } else if (profile.monthly_messages_used >= profile.monthly_messages_limit) {
        return NextResponse.json(
          { error: 'Monthly message limit reached. Upgrade to Pro for unlimited messages.' },
          { status: 429 }
        )
      }
    }

    const body = await request.json()
    const { messages, sessionId } = body as {
      messages: { role: 'user' | 'assistant'; content: string }[]
      sessionId?: string
    }

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json({ error: 'Invalid messages' }, { status: 400 })
    }

    // Call Claude (streaming)
    const stream = await anthropic.messages.create({
      model: 'claude-opus-4-5',
      max_tokens: 1024,
      system: SYSTEM_PROMPT,
      messages,
      stream: true,
    })

    // Collect full response for DB save
    let fullResponse = ''

    const readable = new ReadableStream({
      async start(controller) {
        const encoder = new TextEncoder()
        try {
          for await (const event of stream) {
            if (
              event.type === 'content_block_delta' &&
              event.delta.type === 'text_delta'
            ) {
              const text = event.delta.text
              fullResponse += text
              controller.enqueue(
                encoder.encode(`data: ${JSON.stringify({ text })}\n\n`)
              )
            }
          }
        } catch (err) {
          controller.enqueue(
            encoder.encode(
              `data: ${JSON.stringify({ error: 'Stream error' })}\n\n`
            )
          )
        } finally {
          controller.enqueue(encoder.encode('data: [DONE]\n\n'))
          controller.close()

          // Background: save messages + increment usage
          try {
            const lastUserMsg = messages[messages.length - 1]

            if (sessionId) {
              await supabase.from('messages').insert([
                {
                  session_id: sessionId,
                  user_id: user.id,
                  role: 'user',
                  content: lastUserMsg.content,
                },
                {
                  session_id: sessionId,
                  user_id: user.id,
                  role: 'assistant',
                  content: fullResponse,
                },
              ])

              await supabase
                .from('chat_sessions')
                .update({ updated_at: new Date().toISOString() })
                .eq('id', sessionId)
            }

            await supabase.rpc('increment_message_count', { user_id: user.id })
          } catch {
            // Non-critical — don't fail the response
          }
        }
      },
    })

    return new Response(readable, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        Connection: 'keep-alive',
      },
    })
  } catch (err: unknown) {
    console.error('[/api/chat]', err)
    const message = err instanceof Error ? err.message : 'Internal server error'
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
