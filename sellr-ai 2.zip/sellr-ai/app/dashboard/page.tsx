import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import DashboardClient from '@/components/DashboardClient'

export default async function DashboardPage() {
  const supabase = createClient()
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()

  if (error || !user) redirect('/login')

  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single()

  return (
    <DashboardClient
      user={{
        id: user.id,
        email: user.email ?? '',
        full_name: profile?.full_name ?? user.user_metadata?.full_name ?? '',
        avatar_url: profile?.avatar_url ?? user.user_metadata?.avatar_url ?? '',
        monthly_messages_used: profile?.monthly_messages_used ?? 0,
        monthly_messages_limit: profile?.monthly_messages_limit ?? 50,
        plan: profile?.plan ?? 'free',
      }}
    />
  )
}
