export interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
  created_at?: string
}

export interface ChatSession {
  id: string
  user_id: string
  title: string
  created_at: string
  updated_at: string
  message_count: number
}

export interface UserProfile {
  id: string
  email: string
  full_name?: string
  avatar_url?: string
  whop_store_url?: string
  monthly_messages_used: number
  monthly_messages_limit: number
  plan: 'free' | 'pro'
  created_at: string
}
